<!DOCTYPE html>
<html>
<head>	
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
	<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>StockedUp | Bringing the market to your door</title>
	<style type="text/css">
		*{
			box-sizing: border-box;
			font-family: Montserrat;
		}
		body{
			margin:0;
			background: #fffbe8;
		}
		.firstnav{
			background: white;
			display: table;
			width: 80%;
			border-radius: 20px;
			margin-left: 10%;
			padding: 0 50px;
			margin-top:40px;
			position: fixed;
			z-index: 10000;
		}
		.logo{
			width: 10%;
			float: left;
		}
		.navbar{
			width: 50%;
			float: left;
			margin-left: 15%;
			margin-top:15px;
		}
		.navbar a{
			display: block;
			float: left;
			padding: 10px;
			text-decoration: none;
			color:black;
			font-size: 12px;
		}
		.social-links{
			float: right;
			margin-top:17px;
		}
		.social-links a{
			display: block;
			float: left;
			padding: 5px;
			text-decoration: none;
			color:#ff9700;
			font-size: 14px;
		}
		.hero-container {
            position: relative;
            height: 100vh;
            overflow: hidden;
        }

        .slide {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            opacity: 0;
            transition: opacity 1.5s ease-in-out;
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }

        .slide.active {
            opacity: 1;
        }

        .slide::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, rgba(225,151,0,1) 0%, rgba(225,151,0,1) 20%, rgba(0,0,0,0.3) 100%);
            z-index: 1;
        }

        .slide-content {
            position: relative;
            z-index: 2;
            height: 100%;
            display: flex;
            align-items: center;
            text-align: left;
            color: white;
            padding: 2rem;
        }

        .content-wrapper {
            max-width: 50%;
            animation: slideUp 1s ease-out;
            padding-left: 10% !important;
        }

        .slide.active .content-wrapper {
            animation: slideUp 1s ease-out;
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .slide h1 {
            font-size: 30px;
            margin-bottom: 1.5rem;
            line-height: 1.2;
        }

        .slide p {
            font-size: 14px;
            margin-bottom: 2.5rem;
            line-height: 1.6;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.5);
            opacity: 0.95;
        }

        .cta-button {
            display: inline-block;
            padding: 10px 15px;
            background: linear-gradient(45deg, #ff6b6b, #ee5a24);
            color: white;
            text-decoration: none;
            font-size: 14px;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(255, 107, 107, 0.4);
            border-radius: 5px;
            letter-spacing: 1px;
        }

        .cta-button:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(255, 107, 107, 0.6);
            background: linear-gradient(45deg, #ee5a24, #ff6b6b);
        }

        .slide:nth-child(2) .cta-button {
            background: linear-gradient(45deg, #4834d4, #686de0);
            box-shadow: 0 4px 15px rgba(72, 52, 212, 0.4);
        }

        .slide:nth-child(2) .cta-button:hover {
            box-shadow: 0 8px 25px rgba(72, 52, 212, 0.6);
            background: linear-gradient(45deg, #686de0, #4834d4);
        }

        .slide:nth-child(3) .cta-button {
            background: linear-gradient(45deg, #00d2d3, #54a0ff);
            box-shadow: 0 4px 15px rgba(0, 210, 211, 0.4);
        }

        .slide:nth-child(3) .cta-button:hover {
            box-shadow: 0 8px 25px rgba(0, 210, 211, 0.6);
            background: linear-gradient(45deg, #54a0ff, #00d2d3);
        }

        .navigation {
            position: absolute;
            bottom: 30px;
            left: 50%;
            transform: translateX(-50%);
            display: flex;
            gap: 15px;
            z-index: 3;
        }

        .nav-dot {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.5);
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .nav-dot.active {
            background: white;
            transform: scale(1.2);
        }

        .nav-arrows {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            z-index: 3;
        }

        .nav-arrow {
            background: rgba(255, 255, 255, 0.2);
            border: 2px solid rgba(255, 255, 255, 0.5);
            color: white;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: none;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s ease;
            backdrop-filter: blur(10px);
        }

        .nav-arrow:hover {
            background: rgba(255, 255, 255, 0.3);
            border-color: white;
            transform: scale(1.1);
        }

        .nav-arrow.prev {
            left: 30px;
        }

        .nav-arrow.next {
            right: 30px;
        }
         .about-div {
            display: flex;
            flex-wrap: wrap;
            height: 80vh;
            max-width: 1200px;
            margin: 0 auto;
            padding: 40px 20px;
            align-items: center;
        }

        .shape-container {
            flex: 1;
            min-width: 300px;
            position: relative;
            height: 500px;
            margin-right: 40px;
        }

        .abstract-shape {
            position: absolute;
            width: 100%;
            height: 100%;
            background: url('images/about.png');
            background-size: cover;
            background-position: center;
            clip-path: rect(0 0, 100% 80%, 90% 100%, 20% 50%);
            z-index: 1;
        }

        .shape-overlay {
            position: absolute;
            top: 20px;
            left: -20px;
            width: 100%;
            height: 100%;
            background: #ff9700;
            clip-path: rect(0 0, 100% 80%, 90% 100%, 20% 50%);
            z-index: 0;
            opacity: 0.8;
        }

        .content-container {
            flex: 1;
            min-width: 300px;
            padding: 30px;
        }

        .catchphrase {
            margin-bottom: 10px;
            color: black;
            position: relative;
            display: inline-block;
        }

        .catchphrase::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 0;
            width: 80px;
            height: 4px;
            backgrond: var(--secondary);
        }

        .service-highlight {
            margin-bottom: 20px;
            border-left: 0px solid var(--secondary);
        }
        .service-highlight p {
            color: #555;
            font-size: 1rem;
        }

        .my-divs{
        	width:80%;
        	margin-left: 10%;
        	display: table;
        }
        .titles{
            margin-bottom: 20px;
            color: black;
            position: relative;
            text-align: center;
        }
        .offerings{
        	background: #f1efeb;
        	border:1px solid #fbc87f;
        	border-radius: 5px;
        	padding: 5px 10px;
        	width: 31%;
        	margin-right: 2%;
        	float: left;
        	text-align: center;
        	display: flex;
        	align-items: center;
        	justify-content: center;
        	justify-items: center;
        	margin-bottom: 20px;
        }
        .offerings span{
        	font-size: 14px;
        	display: block;
        	float: left;
        }
        .offerings-icons{
        	font-size: 18px !important;
        	margin-bottom: 0;
        	padding-right: 10px;
        }

        .process-container {
            max-width: 1200px;
            margin: 0 auto;
            position: relative;
        }

        .process-steps {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            position: relative;
            gap: 2rem;
        }

        .step {
            flex: 1;
            text-align: center;
            position: relative;
            z-index: 2;
        }

        .step-icon {
            width: 80px;
            height: 80px;
            background: #f1efeb;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1.5rem;
            border:1px solid #fbc87f;
            transition: all 0.3s ease;
            position: relative;
        }

        .step-icon:hover {
            transform: translateY(-5px) scale(1.1);
            box-shadow: 0 12px 35px rgba(102, 126, 234, 0.4);
        }

        .step:nth-child(2) .step-icon:hover {
            box-shadow: 0 12px 35px rgba(240, 147, 251, 0.4);
        }

        .step:nth-child(3) .step-icon:hover {
            box-shadow: 0 12px 35px rgba(79, 172, 254, 0.4);
        }

        .step:nth-child(4) .step-icon:hover {
            box-shadow: 0 12px 35px rgba(67, 233, 123, 0.4);
        }

        .step-icon .material-icons {
            color: white;
            font-size: 2rem;
        }

        .step-number {
            position: absolute;
            top: -8px;
            right: -8px;
            width: 24px;
            height: 24px;
            background: #ff6b6b;
            color: white;
            border-radius: 50%;
            display: none;
            align-items: center;
            justify-content: center;
            font-size: 0.8rem;
            font-weight: bold;
            border: 3px solid white;
        }

        .step h3 {
            font-size: 1.5rem;
            color: #2d3748;
            margin-bottom: 0.8rem;
            font-weight: 700;
        }

        .step p {
            color: #718096;
            font-size: 1rem;
            line-height: 1.5;
            max-width: 200px;
            margin: 0 auto;
        }

        .connecting-line {
            position: absolute;
            top: 40px;
            left: 10%;
            right: 10%;
            height: 2px;
            background: linear-gradient(90deg, #e2e8f0 0%, #cbd5e0 50%, #e2e8f0 100%);
            z-index: 1;
        }

        .connecting-line::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            height: 100%;
            width: 0;
            background: linear-gradient(90deg, #667eea, #f093fb, #4facfe, #43e97b);
            animation: progressLine 3s ease-in-out infinite;
        }

        @keyframes progressLine {
            0% { width: 0; }
            50% { width: 100%; }
            100% { width: 100%; }
        }

        .for-people{
        	width: 49%;
        	margin-right: 1%;
        	float: left;
        	margin-top:20px;
        	display: table;
        	padding-top:50px;
        }

        .people{
        	width: 49%;
        	float: left;
        	margin-right: 1%;
        	display: table;
        }

        .testimonial-container {
		    height: auto; /* Changed from fixed height to auto */
		    min-height: 300px; /* Add a minimum height */
		    display: flex;
		    align-items: center;
		    justify-content: center;
		    padding: 2rem;
		    position: relative; /* Add this */
		    overflow: hidden; /* Add this */
		}

        .testimonial-slider {
		    max-width: 900px;
		    width: 100%;
		    text-align: center;
		    position: relative;
		    height: 100%; /* Add this */
		}

        .testimonial {
		    opacity: 0;
		    transform: translateY(30px);
		    transition: all 0.5s ease-in-out;
		    position: absolute;
		    width: 80%;
		    top: 0;
		    left: 0;
		    padding: 20px;
		    padding-bottom: 50px;
		    box-sizing: border-box;
		    display: none; /* Add this */
		    margin-left: 10%;
		}

		.testimonial.present_now {
		    opacity: 1;
		    transform: translateY(0);
		    position: relative;
		    display: block; /* Add this */
		}

        .quote-mark {
            font-size: 30px;
            color: #000;
            font-weight: bold;
            line-height: 0.5;
            margin-bottom: 20px;
            font-family: 'Times New Roman', serif;
            animation: fadeInScale 1.2s ease-out;
        }

        .testimonial.present_now .quote-mark {
            animation: fadeInScale 1.2s ease-out;
        }

        @keyframes fadeInScale {
            0% {
                opacity: 0;
                transform: scale(0.5);
            }
            100% {
                opacity: 1;
                transform: scale(1);
            }
        }

        .testimony {
            font-size: 14px;
            line-height: 1.6;
            margin-bottom: 3rem;
            font-style: italic;
            color: #222;
            animation: slideInUp 1s ease-out 0.3s both;
        }

        .testimonial.present_now .testimony {
            animation: slideInUp 1s ease-out 0.3s both;
        }

        @keyframes slideInUp {
            0% {
                opacity: 0;
                transform: translateY(40px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .testifier {
            font-size: 17px;
            font-weight: bold;
            color: #000;
            letter-spacing: 2px;
            position: relative;
            animation: fadeInSlide 1s ease-out 0.6s both;
        }

        .testimonial.present_now .testifier {
            animation: fadeInSlide 1s ease-out 0.6s both;
        }

        .testifier::before {
            content: '';
            width: 60px;
            height: 2px;
            background: #000;
            position: absolute;
            top: 50%;
            left: -80px;
            transform: translateY(-50%);
        }

        .testifier::after {
            content: '';
            width: 60px;
            height: 2px;
            background: #000;
            position: absolute;
            top: 50%;
            right: -80px;
            transform: translateY(-50%);
        }

        @keyframes fadeInSlide {
            0% {
                opacity: 0;
                transform: translateX(30px);
            }
            100% {
                opacity: 1;
                transform: translateX(0);
            }
        }

		.testimonial-navigation {
		    position: absolute;
		    bottom: 50px;
		    left: 50%;
		    transform: translateX(-50%);
		    display: flex;
		    gap: 15px;
		    z-index: 3;
		}

        .dot_nav {
            width: 12px;
            height: 12px;
            border: 2px solid #000;
            border-radius: 50%;
            cursor: pointer;
            transition: all 0.3s ease;
            background: transparent;
        }

        .dot_nav.present_now {
            background: #000;
            transform: scale(1.2);
        }

        .dot_nav:hover {
            background: #000;
        }

        .arrow-navs {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            width: 100%;
            display: flex;
            justify-content: space-between;
            padding: 0 2rem;
            pointer-events: none;
        }

        .arrow-nav {
            width: 30px;
            height: 30px;
            border: 2px solid #000;
            background: transparent;
            color: #000;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 1.5rem;
            pointer-events: auto;
        }

        .arrow-nav:hover {
            background: #000;
            color: white;
            transform: scale(1.1);
        }
        .waitlist-modal {
            display: none;
            position: fixed;
            z-index: 100000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.7);
            backdrop-filter: blur(5px);
        }

        .modal-content {
            background: white;
            margin: 2% auto;
            padding: 0;
            border-radius: 15px;
            width: 90%;
            max-width: 600px;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            position: relative;
        }

        .close-btn {
            position: absolute;
            top: 15px;
            right: 20px;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            z-index: 1001;
            color: #666;
            transition: color 0.3s;
        }

        .close-btn:hover {
            color: #000;
        }

        /* Form Styles */
        #waitlistForm {
            padding: 30px;
        }

        .form-section {
            display: none;
            animation: fadeIn 0.3s ease-in-out;
        }

        .form-section.active {
            display: block;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .form-section h3 {
            color: #333;
            margin-bottom: 25px;
            font-size: 24px;
            text-align: center;
            border-bottom: 2px solid #f0f0f0;
            padding-bottom: 15px;
        }

        .form-section h3 i {
            margin-right: 10px;
            color: #667eea;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 2px solid #e1e1e1;
            border-radius: 8px;
            font-size: 16px;
            transition: border-color 0.3s, box-shadow 0.3s;
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .radio-group,
        .checkbox-group {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .radio-label,
        .checkbox-label {
            display: flex;
            align-items: center;
            padding: 10px;
            border: 2px solid #e1e1e1;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s;
        }

        .radio-label:hover,
        .checkbox-label:hover {
            background-color: #f8f9ff;
            border-color: #667eea;
        }

        .radio-label input,
        .checkbox-label input {
            width: auto;
            margin-right: 10px;
        }

        .other-input {
            margin-top: 10px;
            display: none;
        }

        .other-input.show {
            display: block;
        }

        /* Navigation Buttons */
        .form-navigation {
            display: flex;
            justify-content: space-between;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 2px solid #f0f0f0;
        }

        .prev-btn,
        .next-btn,
        .submit-btn {
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }

        .prev-btn {
            background: #6c757d;
            color: white;
            display: none;
        }

        .prev-btn:hover {
            background: #5a6268;
        }

        .next-btn {
            background: #667eea;
            color: white;
            margin-left: auto;
        }

        .next-btn:hover {
            background: #5a67d8;
        }

        .submit-btn {
            background: #28a745;
            color: white;
            display: none;
        }

        .submit-btn:hover {
            background: #218838;
        }

        .submit-btn:disabled {
            background: #6c757d;
            cursor: not-allowed;
        }

        /* Progress Indicator */
        .progress-indicator {
            display: flex;
            justify-content: center;
            margin-bottom: 30px;
            padding: 0 30px;
        }

        .progress-step {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background: #e1e1e1;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 10px;
            font-weight: bold;
            color: #666;
            position: relative;
        }

        .progress-step.active {
            background: #667eea;
            color: white;
        }

        .progress-step.completed {
            background: #28a745;
            color: white;
        }

        .progress-step:not(:last-child)::after {
            content: '';
            position: absolute;
            left: 100%;
            top: 50%;
            width: 20px;
            height: 2px;
            background: #e1e1e1;
            transform: translateY(-50%);
        }

        .progress-step.completed:not(:last-child)::after {
            background: #28a745;
        }
        
        /* Creative Mobile Responsiveness */
@media (max-width: 1024px) {
    /* Tablet and below */
    .firstnav {
        width: 90%;
        margin-left: 5%;
        padding: 0 30px;
    }
    
    .navbar {
        width: 60%;
        margin-left: 10%;
    }
    
    .content-wrapper {
        max-width: 70%;
    }
    
    .offerings {
        width: 48%;
        margin-right: 2%;
    }
}

@media (max-width: 768px) {
    /* Small tablets and large phones */
    .firstnav {
        padding: 0 20px;
        margin-top: 20px;
        border-radius: 15px;
        width:95%;
        margin-left: 2.5%;
    }
    
    .logo {
        width: 15%;
    }
    
    .navbar {
        width: 60%;
        margin-left: 10%;
        margin-top: 20px;
    }
    
    .navbar a {
        padding: 8px;
        font-size: 11px;
    }
    
    .social-links {
        margin-top: 20px;
    }

    .hero-container{
    	height: 500px !important;
    }
    
    .slide-content {
        padding: 1rem;
    }
    
    .content-wrapper {
        max-width: 80%;
        padding-left: 5% !important;
    }
    
    .slide h1 {
        font-size: 24px;
    }
    
    .nav-arrow {
        width: 40px;
        height: 40px;
    }
    
    .nav-arrow.prev {
        left: 15px;
    }
    
    .nav-arrow.next {
        right: 15px;
    }
    
    .navigation {
        bottom: 20px;
    }
    
    .about-div {
        flex-direction: column;
        padding: 30px 15px;
        display: table;
        height: auto;
    }
    
    .shape-container {
        height: 700px !important;
        margin-right: 0;
        margin-bottom: 30px;
        min-width: 90%;
    }
    
    .content-container {
        padding: 15px;
    }
    
    .process-steps {
        flex-direction: column;
        align-items: center;
        gap: 3rem;
    }
    
    .connecting-line {
        display: none;
    }
    
    .step::after {
        content: '';
        position: absolute;
        bottom: -1.5rem;
        left: 50%;
        transform: translateX(-50%);
        width: 2px;
        height: 3rem;
        background: linear-gradient(180deg, #e2e8f0, transparent);
        z-index: 1;
    }
    
    .step:last-child::after {
        display: none;
    }
    
    .step {
        max-width: 300px;
    }
    
    .step h3 {
        font-size: 1.3rem;
    }
    
    .step p {
        max-width: 250px;
    }
    
    .people {
        width: 100%;
        margin-right: 0;
    }
    
    .testimonial {
        width: 90%;
        margin-left: 5%;
    }
    .modal-content {
                width: 95%;
                margin: 5% auto;
            }

            .radio-group,
            .checkbox-group {
                gap: 8px;
            }

            .form-navigation {
                flex-direction: column;
                gap: 10px;
            }

            .next-btn {
                margin-left: 0;
            }
}

@media (max-width: 600px) {
    /* Most mobile phones */
    .firstnav {
        width: 100%;
        padding: 10px 15px;
        position: relative; /* Change from fixed to relative for better mobile flow */
        margin-top:0;
        margin-left:0;
        border-radius: 0;
    }
    
    .logo {
        width: 25%;
        float: none;
        display: block;
        margin: 0 auto;
    }
    
    .navbar, .social-links {
        width: 100%;
        float: none;
        margin: 10px 0 0 0;
        text-align: center;
    }
    
    .navbar a {
        float: none;
        display: inline-block;
        padding: 8px 10px;
    }
    
    .social-links a {
        float: none;
        display: inline-block;
        padding: 5px 8px;
    }
    
    .hero-container {
        margin-top: 0px; /* Add space since nav is no longer fixed */
        height:600px;
    }
    
    .content-wrapper {
        max-width: 90%;
        padding-left: 5% !important;
        padding-top:20%;
    }
    
    .slide h1 {
        font-size: 20px;
        margin-bottom: 0.8rem;
    }
    
    .slide p {
        font-size: 12px;
        margin-bottom: 1.5rem;
    }
    
    .cta-button {
        padding: 8px 12px;
        font-size: 12px;
    }
    
    .offerings {
        width: 100%;
        margin-right: 0;
        padding: 10px;
        text-align: left;
    }
    
    .offerings span {
        font-size: 13px;
    }
    
    .offerings-icons {
        font-size: 16px !important;
    }
    
    .step-icon {
        width: 60px;
        height: 60px;
    }
    
    .step-icon .material-icons {
        font-size: 1.5rem;
    }
    
    .step h3 {
        font-size: 1.1rem;
    }
    
    .step p {
        font-size: 0.8rem;
    }
    
    .testimonial-container {
        padding: 1rem 0;
    }
    
    .testimony {
        font-size: 13px;
        margin-bottom: 2rem;
    }
    
    .testifier {
        font-size: 15px;
    }
    
    .testifier::before, 
    .testifier::after {
        width: 30px;
    }
    
    .testifier::before {
        left: -50px;
    }
    
    .testifier::after {
        right: -50px;
    }
    
    footer div {
        flex-direction: column;
        text-align: center;
    }
    
    footer div > div {
        margin-bottom: 20px;
    }
}

@media (max-width: 450px) {
    /* Small mobile phones */
    .navbar a {
        padding: 5px;
        font-size: 10px;
    }


    .social-links a {
        padding: 3px 5px;
        font-size: 12px;
    }
    
    .content-wrapper {
        max-width: 95%;
        padding-top: 45%;
    }
    
    .slide h1 {
        font-size: 18px;
    }
    
    .slide p {
        font-size: 11px;
    }
    
    .cta-button {
        padding: 7px 10px;
    }
    
    .step-icon {
        width: 50px;
        height: 50px;
    }
    
    .step h3 {
        font-size: 1rem;
    }
    
    .step p {
        font-size: 0.7rem;
    }
    
    .testimony {
        font-size: 12px;
    }
    
    .testifier {
        font-size: 14px;
    }
    .for-people{
    	width: 100%;
    	margin-right: 0;
    }
    .testimonial{
    	width: 100% !important;
    	margin-left: 0 !important;
    }
    .testimonial-container{
    	padding: 0;
    }
    .arrow-nav{
    	display: none;
    }
}

/* Creative Orientation-Based Styles */
@media (max-width: 768px) and (orientation: portrait) {
    /* Portrait-specific styles */
    .hero-container {
        height: 80vh;
    }
    
    .slide-content {
        align-items: flex-start;
        padding-top: 20%;
    }
    
    .slide::before {
        background: linear-gradient(180deg, rgba(225,151,0,0.8) 0%, rgba(225,151,0,0.6) 30%, rgba(0,0,0,0.3) 100%);
    }
}

@media (max-width: 768px) and (orientation: landscape) {
    /* Landscape-specific styles */
    .hero-container {
        height: 120vh;
    }
    
    .firstnav {
        position: relative;
        margin-top: 15px;
    }
}

/* Creative Dark Mode Adaptation */
@media (prefers-color-scheme: dark) and (max-width: 768px) {
    body {
        background: #121212;
    }
    
    .firstnav, .offerings, .step-icon {
        background: #1e1e1e;
        border-color: #333;
    }
    
    .slide::before {
        background: linear-gradient(90deg, rgba(225,151,0,0.8) 0%, rgba(225,151,0,0.6) 20%, rgba(0,0,0,0.7) 100%);
    }
    
    .titles, .catchphrase, .step h3 {
        color: #fff;
    }
    
    .service-highlight p, .step p {
        color: #ccc;
    }
    
    .testimony {
        color: #eee;
    }
}

/* Creative Motion Reduction */
@media (prefers-reduced-motion: reduce) {
    * {
        animation: none !important;
        transition: none !important;
    }
    
    .slide {
        transition: none !important;
    }
    
    .connecting-line::before {
        animation: none !important;
        width: 100%;
    }
}

/* Creative Very Small Height Devices */
@media (max-height: 600px) {
    .hero-container {
        height: 120vh;
    }
    
    .slide-content {
        padding-top: 15%;
    }
    
    .navigation {
        bottom: 10px;
    }
}

/* Foldable Devices Support */
@media (max-width: 600px) and (max-height: 300px) {
    .hero-container {
        height: 150vh;
    }
    
    .firstnav {
        padding: 5px 10px;
    }
    
    .navbar a {
        padding: 3px 5px;
        font-size: 9px;
    }
    
    .slide h1 {
        font-size: 16px;
    }
    
    .slide p {
        font-size: 10px;
        margin-bottom: 1rem;
    }
}
	</style>
</head>
<body>
	<div class="hero-container">

	<div class="firstnav">
		<img src="images/logo.png" alt="logo" class="logo">
		<div class="navbar">
			<a href="#home">Home</a>
			<a href="#about">Who we are</a>
			<a href="#choose">Choose us</a>
			<a href="#offer">Our offer</a>
			<a href="#testimonial">Testimonial</a>
		</div>
		<div class="social-links">
			<a href="https://www.facebook.com/share/1B3ek2hv15/"><i class="bi bi-facebook"></i></a>
			<a href="https://x.com/StockedUpApp"><i class="bi bi-twitter-x"></i></a>
			<a href="https://www.linkedin.com/company/stockedup-ltd/"><i class="bi bi-linkedin"></i></a>
		</div>
	</div>
        <!-- Slide 1 -->
        <div class="slide active" style="background-image: url('images/slide1.jpg');">
            <div class="slide-content">
                <div class="content-wrapper">
                    <h1>Grocery Shopping Made Effortless!</h1>
                    <p>Stockedup brings the market to your door, saving you time for busy professionals and families like you.</p>
                    <a href="#" class="cta-button">Join the Waitlist</a>
                </div>
            </div>
        </div>

        <!-- Slide 2 -->
        <div class="slide" style="background-image: url('images/slide2.jpg');">
            <div class="slide-content">
                <div class="content-wrapper">
                    <h1>Grocery Shopping Made Effortless!</h1>
                    <p>Stockedup brings the market to your door, saving you time for busy professionals and families like you.</p>
                    <a href="#" class="cta-button">Join the Waitlist</a>
                </div>
            </div>
        </div>

        <!-- Slide 3 -->
        <div class="slide" style="background-image: url('images/slide3.jpg');">
            <div class="slide-content">
                <div class="content-wrapper">
                    <h1>Grocery Shopping Made Effortless!</h1>
                    <p>Stockedup brings the market to your door, saving you time for busy professionals and families like you.</p>
                    <a href="#" class="cta-button">Join the Waitlist</a>
                </div>
            </div>
        </div>

        <!-- Navigation Arrows -->
        <div class="nav-arrows">
            <div class="nav-arrow prev" onclick="changeSlide(-1)">‹</div>
            <div class="nav-arrow next" onclick="changeSlide(1)">›</div>
        </div>

        <!-- Navigation Dots -->
        <div class="navigation">
            <div class="nav-dot active" onclick="currentSlide(1)"></div>
            <div class="nav-dot" onclick="currentSlide(2)"></div>
            <div class="nav-dot" onclick="currentSlide(3)"></div>
        </div>
    </div>

    <div class="">
    	<div class="about-div">
        <div class="shape-container">
            <div class="abstract-shape"></div>
            <div class="shape-overlay"></div>
        </div>
        
        <div class="content-container">
            <h1 class="catchphrase">Who we Are</h1>
            
            <div class="service-highlight">
               <p>StockedUp bridges the gap between busy individuals (buyers) and trusted vendors. We make it easy for buyers to get fresh groceries delivered fast, while empowering vendors with a reliable platform to grow their business</p>
            </div>
            <h1 class="catchphrase">Why Choose us</h1>
            
            <div class="service-highlight">
               <ul>
               		<li>Curated Vendors</li>
               		<li>Fast Delivery</li>
               		<li>Friendly User-Interface</li>
               		<li>Excellent Customer Support</li>
               		<li>Transparency Pricing</li>
               		<li>Loyalty Points & Referal Bonuses</li>
               </ul>
            </div>
        </div>
    </div>
    </div>
    <div class="my-divs">
    	<h1 class="titles">What we Offer</h1>
    	<div class="offerings">
    		<span class="material-symbols-outlined offerings-icons">rice_bowl</span> <span>Groceries & Foodstuffs</span>
    	</div>
    	<div class="offerings">
    		<span class="material-symbols-outlined offerings-icons">rice_bowl</span> <span>Canned Foods</span>
    	</div>
    	<div class="offerings">
    		<span class="material-symbols-outlined offerings-icons">rice_bowl</span> <span>Fresh Veggies</span>
    	</div>
    	<div class="offerings">
    		<span class="material-symbols-outlined offerings-icons">rice_bowl</span> <span>Flour & Grains</span>
    	</div>
    	<div class="offerings">
    		<span class="material-symbols-outlined offerings-icons">rice_bowl</span> <span>Customer Dashboard</span>
    	</div>
    	<div class="offerings">
    		<span class="material-symbols-outlined offerings-icons">rice_bowl</span> <span>Doorstep Delivery</span>
    	</div>
    </div>

    <div class="process-container">
    	<h1 class="titles">How it Works</h1>
        <div class="process-steps">
            <div class="connecting-line"></div>
            
            <div class="step">
                <div class="step-icon">
                    <span class="material-symbols-outlined">search</span>
                    <div class="step-number">1</div>
                </div>
                <h3>Browse</h3>
                <p>Explore our variety of products</p>
            </div>

            <div class="step">
                <div class="step-icon">
                    <span class="material-symbols-outlined">shopping_cart</span>
                    <div class="step-number">2</div>
                </div>
                <h3>Order</h3>
                <p>Add items to your cart</p>
            </div>

            <div class="step">
                <div class="step-icon">
                    <span class="material-symbols-outlined">local_shipping</span>
                    <div class="step-number">3</div>
                </div>
                <h3>Track</h3>
                <p>Monitor your delivery in real time</p>
            </div>

            <div class="step">
                <div class="step-icon">
                    <span class="material-symbols-outlined">check_circle</span>
                    <div class="step-number">4</div>
                </div>
                <h3>Delivered</h3>
                <p>Receive your order at your doorstep</p>
            </div>
        </div>
    </div>

    <div class="my-divs">
    	<div class="people">
    	<div class="for-people">
    		<h2>For Customers</h2>
    		<p>Convinient Ordering <br> Affordable Prices <br> Doorstep Delivery</p>
    	</div>
    	<div class="for-people">
    		<h2>For Vendors</h2>
    		<p>Reach More Customers <br> Easy Inventory Mgt <br> Delivery Support</p>
    	</div>
    </div>
    <div class="people">
    	<div class="testimonial-container">
        <div class="testimonial-slider">
            <!-- Testimonial 1 -->
            <div class="testimonial present_now">
                <div class="quote-mark">"</div>
                <p class="testimony">This service completely transformed our business. The attention to detail and professional approach exceeded all our expectations. Truly outstanding work!</p>
                <div class="testifier">Sarah Johnson</div>
            </div>

            <!-- Testimonial 2 -->
            <div class="testimonial">
                <div class="quote-mark">"</div>
                <p class="testimony">I've never experienced such dedication and quality. The team went above and beyond to deliver exactly what we needed. Highly recommended!</p>
                <div class="testifier">Michael Chen</div>
            </div>

            <!-- Testimonial 3 -->
            <div class="testimonial">
                <div class="quote-mark">"</div>
                <p class="testimony">Exceptional results that speak for themselves. Professional, reliable, and incredibly talented. This is the partnership we've been looking for.</p>
                <div class="testifier">Emma Rodriguez</div>
            </div>

            <!-- Testimonial 4 -->
            <div class="testimonial">
                <div class="quote-mark">"</div>
                <p class="testimony">From start to finish, everything was perfect. Clear communication, timely delivery, and results that exceeded our wildest dreams.</p>
                <div class="testifier">David Thompson</div>
            </div>

            <!-- Testimonial 5 -->
            <div class="testimonial">
                <div class="quote-mark">"</div>
                <p class="testimony">Outstanding creativity and flawless execution. They understood our vision perfectly and brought it to life in ways we never imagined possible.</p>
                <div class="testifier">Lisa Park</div>
            </div>
        </div>

        <!-- Navigation Arrows -->
        <div class="arrow-navs">
            <div class="arrow-nav" onclick="changeTestimonial(-1)">‹</div>
            <div class="arrow-nav" onclick="changeTestimonial(1)">›</div>
        </div>

        <!-- Navigation Dots -->
		<div class="testimonial-navigation">
		    <div class="dot_nav present_now" onclick="currentTestimonial(1)"></div>
		    <div class="dot_nav" onclick="currentTestimonial(2)"></div>
		    <div class="dot_nav" onclick="currentTestimonial(3)"></div>
		    <div class="dot_nav" onclick="currentTestimonial(4)"></div>
		    <div class="dot_nav" onclick="currentTestimonial(5)"></div>
		</div>
    </div>
    </div>
    </div>


    <footer style="background-color: #fffbe8; padding: 40px 0; border-top: 1px solid #fbc87f;">
    <div style="max-width: 1200px; margin: 0 auto; padding: 0 20px; display: flex; flex-wrap: wrap;">
        <!-- Logo Column -->
        <div style="flex: 1; min-width: 250px; padding: 15px;">
            <img src="images/logo.png" alt="StockedUp Logo" style="max-width: 150px; margin-bottom: 20px;">
            <p style="color: #555; font-size: 14px; line-height: 1.6;">Bringing the market to your door with convenience and reliability.</p>
            <div style="margin-top: 20px;">
                <a href="https://www.facebook.com/share/1B3ek2hv15/" style="color: #ff9700; margin-right: 15px; font-size: 18px;"><i class="bi bi-facebook"></i></a>
                <a href="https://x.com/StockedUpApp" style="color: #ff9700; margin-right: 15px; font-size: 18px;"><i class="bi bi-twitter-x"></i></a>
                <a href="https://www.linkedin.com/company/stockedup-ltd/" style="color: #ff9700; font-size: 18px;"><i class="bi bi-linkedin"></i></a>
            </div>
        </div>

        <!-- Categories Column -->
        <div style="flex: 1; min-width: 250px; padding: 15px;">
            <h3 style="color: #333; font-size: 18px; margin-bottom: 20px; position: relative; padding-bottom: 10px;">
                Categories
                <span style="position: absolute; bottom: 0; left: 0; width: 50px; height: 3px; background-color: #ff9700;"></span>
            </h3>
            <ul style="list-style: none; padding: 0; margin: 0;">
                <li style="margin-bottom: 10px;"><a href="#" style="color: #555; text-decoration: none; font-size: 14px; transition: color 0.3s;">Groceries & Foodstuffs</a></li>
                <li style="margin-bottom: 10px;"><a href="#" style="color: #555; text-decoration: none; font-size: 14px; transition: color 0.3s;">Canned Foods</a></li>
                <li style="margin-bottom: 10px;"><a href="#" style="color: #555; text-decoration: none; font-size: 14px; transition: color 0.3s;">Fresh Veggies</a></li>
                <li style="margin-bottom: 10px;"><a href="#" style="color: #555; text-decoration: none; font-size: 14px; transition: color 0.3s;">Flour & Grains</a></li>
                <li><a href="#" style="color: #555; text-decoration: none; font-size: 14px; transition: color 0.3s;">See All Categories</a></li>
            </ul>
        </div>

        <!-- Policy Column -->
        <div style="flex: 1; min-width: 250px; padding: 15px;">
            <h3 style="color: #333; font-size: 18px; margin-bottom: 20px; position: relative; padding-bottom: 10px;">
                Policy
                <span style="position: absolute; bottom: 0; left: 0; width: 50px; height: 3px; background-color: #ff9700;"></span>
            </h3>
            <ul style="list-style: none; padding: 0; margin: 0;">
                <li style="margin-bottom: 10px;"><a href="#" style="color: #555; text-decoration: none; font-size: 14px; transition: color 0.3s;">Return Policy</a></li>
                <li style="margin-bottom: 10px;"><a href="#" style="color: #555; text-decoration: none; font-size: 14px; transition: color 0.3s;">Shipping Policy</a></li>
                <li style="margin-bottom: 10px;"><a href="#" style="color: #555; text-decoration: none; font-size: 14px; transition: color 0.3s;">Quality Guarantee</a></li>
                <li><a href="#" style="color: #555; text-decoration: none; font-size: 14px; transition: color 0.3s;">Vendor Terms</a></li>
            </ul>
        </div>

        <!-- Contact Column -->
        <div style="flex: 1; min-width: 250px; padding: 15px;">
            <h3 style="color: #333; font-size: 18px; margin-bottom: 20px; position: relative; padding-bottom: 10px;">
                Contact
                <span style="position: absolute; bottom: 0; left: 0; width: 50px; height: 3px; background-color: #ff9700;"></span>
            </h3>
            <ul style="list-style: none; padding: 0; margin: 0;">
                <li style="margin-bottom: 10px; display: flex; align-items: center;">
                    <i class="bi bi-geo-alt" style="color: #ff9700; margin-right: 10px;"></i>
                    <span style="color: #555; font-size: 14px;">Anambra, Nigeria</span>
                </li>
                <li style="margin-bottom: 10px; display: flex; align-items: center;">
                    <i class="bi bi-telephone" style="color: #ff9700; margin-right: 10px;"></i>
                    <span style="color: #555; font-size: 14px;">+234 907 150 7558</span>
                </li>
                <li style="display: flex; align-items: center;">
                    <i class="bi bi-envelope" style="color: #ff9700; margin-right: 10px;"></i>
                    <span style="color: #555; font-size: 14px;">hello@stockedup.com</span>
                </li>
            </ul>
        </div>
    </div>

    <!-- Bottom Footer -->
    <div style="background-color: #f1efeb; padding: 20px 0; margin-top: 40px;">
        <div style="max-width: 1200px; margin: 0 auto; padding: 0 20px; display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center;">
            <div style="color: #555; font-size: 12px;">
                &copy; 2025 StockedUp. All rights reserved.
            </div>
            <div>
                <a href="#" style="color: #555; text-decoration: none; font-size: 12px; margin-left: 20px;">Privacy Policy</a>
                <a href="#" style="color: #555; text-decoration: none; font-size: 12px; margin-left: 20px;">Terms of Service</a>
                <a href="#" style="color: #555; text-decoration: none; font-size: 12px; margin-left: 20px;">Cookies</a>
            </div>
        </div>
    </div>
</footer>

    <!-- Waitlist Modal -->
    <div class="waitlist-modal" id="waitlistModal">
        <div class="modal-content">
            <span class="close-btn">&times;</span>
            
            <!-- Progress Indicator -->
            <div class="progress-indicator">
                <div class="progress-step active" data-step="1">1</div>
                <div class="progress-step" data-step="2">2</div>
                <div class="progress-step" data-step="3">3</div>
            </div>

            <form id="waitlistForm" action="send_email.php" method="POST">
                <!-- Section 1: Basic Info -->
                <div class="form-section active" data-section="1">
                    <h3><i class="fas fa-user"></i> Basic Information</h3>

                    <div class="form-group">
                        <label>Full Name</label>
                        <input type="text" name="full_name" required>
                    </div>

                    <div class="form-group">
                        <label>Email Address</label>
                        <input type="email" name="email" required>
                    </div>

                    <div class="form-group">
                        <label>Phone Number</label>
                        <input type="tel" name="phone" required>
                    </div>

                    <div class="form-group radio-group">
                        <label>I am signing up as:</label>
                        <label class="radio-label">
                            <input type="radio" name="user_type" value="buyer" required checked>
                            <span>Buyer</span>
                        </label>
                        <label class="radio-label">
                            <input type="radio" name="user_type" value="seller">
                            <span>Seller (Vendor)</span>
                        </label>
                    </div>
                </div>

                <!-- Section 2A: Buyer Section -->
                <div class="form-section" data-section="2a">
                    <h3><i class="fas fa-shopping-bag"></i> Buyer Information</h3>

                    <div class="form-group">
                        <label>Delivery Address (City/State)</label>
                        <input type="text" name="buyer_address" required>
                    </div>

                    <div class="form-group checkbox-group">
                        <label>What type of foodstuff are you interested in?</label>
                        <label class="checkbox-label">
                            <input type="checkbox" name="buyer_interests[]" value="fruits">
                            <span>Fruits</span>
                        </label>
                        <label class="checkbox-label">
                            <input type="checkbox" name="buyer_interests[]" value="vegetables">
                            <span>Vegetables</span>
                        </label>
                        <label class="checkbox-label">
                            <input type="checkbox" name="buyer_interests[]" value="grains">
                            <span>Grains</span>
                        </label>
                        <label class="checkbox-label">
                            <input type="checkbox" name="buyer_interests[]" value="dairy">
                            <span>Dairy</span>
                        </label>
                        <label class="checkbox-label">
                            <input type="checkbox" name="buyer_interests[]" value="meat">
                            <span>Meat</span>
                        </label>
                        <label class="checkbox-label">
                            <input type="checkbox" name="buyer_interests[]" value="packaged_goods">
                            <span>Packaged goods</span>
                        </label>
                        <label class="checkbox-label">
                            <input type="checkbox" name="buyer_interests[]" value="other">
                            <span>Others</span>
                        </label>
                        <input type="text" name="buyer_interests_other" placeholder="Specify other interests" class="other-input">
                    </div>

                    <div class="form-group radio-group">
                        <label>How often do you shop for foodstuffs?</label>
                        <label class="radio-label">
                            <input type="radio" name="shopping_frequency" value="daily" required>
                            <span>Daily</span>
                        </label>
                        <label class="radio-label">
                            <input type="radio" name="shopping_frequency" value="weekly">
                            <span>Weekly</span>
                        </label>
                        <label class="radio-label">
                            <input type="radio" name="shopping_frequency" value="bi-weekly">
                            <span>Bi-weekly</span>
                        </label>
                        <label class="radio-label">
                            <input type="radio" name="shopping_frequency" value="monthly">
                            <span>Monthly</span>
                        </label>
                        <label class="radio-label">
                            <input type="radio" name="shopping_frequency" value="occasionally">
                            <span>Occasionally</span>
                        </label>
                    </div>

                    <div class="form-group">
                        <label>Why do you want to use StockedUp?</label>
                        <textarea name="buyer_why" required rows="4"></textarea>
                    </div>
                </div>

                <!-- Section 2B: Seller Section -->
                <div class="form-section" data-section="2b">
                    <h3><i class="fas fa-store"></i> Vendor Information</h3>

                    <div class="form-group">
                        <label>Business Name</label>
                        <input type="text" name="business_name" required>
                    </div>

                    <div class="form-group">
                        <label>Business Address (City/State)</label>
                        <input type="text" name="business_address" required>
                    </div>

                    <div class="form-group checkbox-group">
                        <label>What type of products do you sell?</label>
                        <label class="checkbox-label">
                            <input type="checkbox" name="products_sold[]" value="fruits">
                            <span>Fruits</span>
                        </label>
                        <label class="checkbox-label">
                            <input type="checkbox" name="products_sold[]" value="vegetables">
                            <span>Vegetables</span>
                        </label>
                        <label class="checkbox-label">
                            <input type="checkbox" name="products_sold[]" value="grains">
                            <span>Grains</span>
                        </label>
                        <label class="checkbox-label">
                            <input type="checkbox" name="products_sold[]" value="meats">
                            <span>Meats</span>
                        </label>
                        <label class="checkbox-label">
                            <input type="checkbox" name="products_sold[]" value="dairy">
                            <span>Dairy</span>
                        </label>
                        <label class="checkbox-label">
                            <input type="checkbox" name="products_sold[]" value="packaged_goods">
                            <span>Packaged goods</span>
                        </label>
                        <label class="checkbox-label">
                            <input type="checkbox" name="products_sold[]" value="other">
                            <span>Others</span>
                        </label>
                        <input type="text" name="products_sold_other" placeholder="Specify other products" class="other-input">
                    </div>

                    <div class="form-group">
                        <label>Why do you want to join StockedUp as a vendor?</label>
                        <textarea name="seller_why" required rows="4"></textarea>
                    </div>
                </div>

                <!-- Final Section -->
                <div class="form-section" data-section="3">
                    <h3><i class="fas fa-flag-checkered"></i> Final Details</h3>
                    <div class="form-group">
                        <label>How did you hear about us?</label>
                        <select name="referral_source" required>
                            <option value="">Select an option</option>
                            <option value="social_media">Social Media</option>
                            <option value="whatsapp">WhatsApp</option>
                            <option value="referral">Referral</option>
                            <option value="event">Event or Campus Activation</option>
                            <option value="other">Other</option>
                        </select>
                    </div>
                </div>

                <!-- Form Navigation -->
                <div class="form-navigation">
                    <button type="button" class="prev-btn">Back</button>
                    <button type="button" class="next-btn">Continue</button>
                    <button type="submit" class="submit-btn">Join Waitlist</button>
                </div>
            </form>
        </div>
    </div>
   <script>
        // Modal Control
        const modal = document.getElementById('waitlistModal');
        const ctaButtons = document.querySelectorAll('.cta-button');
        const closeBtn = document.querySelector('.close-btn');

        ctaButtons.forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                modal.style.display = 'block';
                document.body.style.overflow = 'hidden';
            });
        });

        closeBtn.addEventListener('click', () => {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        });

        window.addEventListener('click', (e) => {
            if(e.target === modal) {
                modal.style.display = 'none';
                document.body.style.overflow = 'auto';
            }
        });

        // Form Navigation Logic
        const formSections = document.querySelectorAll('.form-section');
        const prevBtn = document.querySelector('.prev-btn');
        const nextBtn = document.querySelector('.next-btn');
        const submitBtn = document.querySelector('.submit-btn');
        const progressSteps = document.querySelectorAll('.progress-step');

        let currentSection = 0;
        let totalSections = 3; // Basic Info, User-specific section, Final Details

        // Function to show specific section
        function showSection(sectionIndex) {
            // Hide all sections
            formSections.forEach(section => {
                section.classList.remove('active');
            });

            // Determine which section to show based on user type and section index
            let sectionToShow;
            
            if (sectionIndex === 0) {
                // Always show basic info first
                sectionToShow = document.querySelector('[data-section="1"]');
            } else if (sectionIndex === 1) {
                // Show user-specific section based on selected user type
                const userType = document.querySelector('input[name="user_type"]:checked').value;
                sectionToShow = document.querySelector(`[data-section="2${userType === 'buyer' ? 'a' : 'b'}"]`);
            } else if (sectionIndex === 2) {
                // Show final section
                sectionToShow = document.querySelector('[data-section="3"]');
            }

            // Show the determined section
            if (sectionToShow) {
                sectionToShow.classList.add('active');
            }

            // Update progress indicator
            updateProgressIndicator(sectionIndex);
            
            // Update navigation buttons
            updateNavigation();
        }

        // Function to update progress indicator
        function updateProgressIndicator(currentIndex) {
            progressSteps.forEach((step, index) => {
                step.classList.remove('active', 'completed');
                
                if (index < currentIndex) {
                    step.classList.add('completed');
                } else if (index === currentIndex) {
                    step.classList.add('active');
                }
            });
        }

        // Function to update navigation buttons
        function updateNavigation() {
            // Show/hide back button
            if (currentSection === 0) {
                prevBtn.style.display = 'none';
            } else {
                prevBtn.style.display = 'inline-block';
            }

            // Show/hide next/submit buttons
            if (currentSection === totalSections - 1) {
                nextBtn.style.display = 'none';
                submitBtn.style.display = 'inline-block';
            } else {
                nextBtn.style.display = 'inline-block';
                submitBtn.style.display = 'none';
            }
        }

        // Function to validate current section
        function validateSection(sectionIndex) {
            const currentSectionEl = document.querySelector('.form-section.active');
            
            if (!currentSectionEl) {
                return true;
            }
            
            const requiredFields = currentSectionEl.querySelectorAll('[required]');
            let isValid = true;
            let errorMessage = '';

            requiredFields.forEach(field => {
                // Skip validation for hidden fields or disabled fields
                if (field.offsetParent === null || field.disabled) {
                    return;
                }

                if (field.type === 'radio') {
                    const radioGroup = currentSectionEl.querySelectorAll(`[name="${field.name}"]`);
                    const isChecked = Array.from(radioGroup).some(radio => radio.checked);
                    if (!isChecked) {
                        isValid = false;
                        errorMessage = 'Please select an option for all required fields';
                    }
                } else if (field.type === 'checkbox') {
                    const checkboxGroup = currentSectionEl.querySelectorAll(`[name="${field.name}"]`);
                    const isChecked = Array.from(checkboxGroup).some(checkbox => checkbox.checked);
                    if (!isChecked) {
                        isValid = false;
                        errorMessage = 'Please select at least one option';
                    }
                } else if (!field.value.trim()) {
                    isValid = false;
                    errorMessage = 'Please fill in all required fields';
                    try {
                        field.focus();
                    } catch (e) {
                        console.log('Could not focus field:', field.name);
                    }
                }
            });

            if (!isValid && errorMessage) {
                alert(errorMessage);
            }

            return isValid;
        }

        // Navigation event listeners
        nextBtn.addEventListener('click', () => {
            if (validateSection(currentSection)) {
                if (currentSection < totalSections - 1) {
                    currentSection++;
                    showSection(currentSection);
                }
            }
        });

        prevBtn.addEventListener('click', () => {
            if (currentSection > 0) {
                currentSection--;
                showSection(currentSection);
            }
        });

        // Function to toggle required fields and handle user type changes
        function toggleRequiredFields(userType) {
            const buyerSection = document.querySelector('[data-section="2a"]');
            const sellerSection = document.querySelector('[data-section="2b"]');
            
            const buyerRequiredFields = buyerSection.querySelectorAll('[required]');
            const sellerRequiredFields = sellerSection.querySelectorAll('[required]');

            if (userType === 'buyer') {
                buyerRequiredFields.forEach(field => {
                    field.setAttribute('required', '');
                });
                sellerRequiredFields.forEach(field => {
                    field.removeAttribute('required');
                });
            } else {
                sellerRequiredFields.forEach(field => {
                    field.setAttribute('required', '');
                });
                buyerRequiredFields.forEach(field => {
                    field.removeAttribute('required');
                });
            }
        }

        // Function to setup other inputs
        function setupOtherInputs() {
            // Handle buyer interests "other" option
            const buyerOtherCheckbox = document.querySelector('input[name="buyer_interests[]"][value="other"]');
            const buyerOtherInput = document.querySelector('input[name="buyer_interests_other"]');
            
            if (buyerOtherCheckbox && buyerOtherInput) {
                buyerOtherCheckbox.addEventListener('change', function() {
                    if (this.checked) {
                        buyerOtherInput.classList.add('show');
                        buyerOtherInput.required = true;
                    } else {
                        buyerOtherInput.classList.remove('show');
                        buyerOtherInput.required = false;
                        buyerOtherInput.value = '';
                    }
                });
            }

            // Handle seller products "other" option
            const sellerOtherCheckbox = document.querySelector('input[name="products_sold[]"][value="other"]');
            const sellerOtherInput = document.querySelector('input[name="products_sold_other"]');
            
            if (sellerOtherCheckbox && sellerOtherInput) {
                sellerOtherCheckbox.addEventListener('change', function() {
                    if (this.checked) {
                        sellerOtherInput.classList.add('show');
                        sellerOtherInput.required = true;
                    } else {
                        sellerOtherInput.classList.remove('show');
                        sellerOtherInput.required = false;
                        sellerOtherInput.value = '';
                    }
                });
            }
        }

        // Initialize everything when DOM is loaded
        document.addEventListener('DOMContentLoaded', function() {
            const userTypeRadios = document.querySelectorAll('input[name="user_type"]');

            // Handle user type selection
            userTypeRadios.forEach(radio => {
                radio.addEventListener('change', function() {
                    toggleRequiredFields(this.value);
                });
            });

            // Initialize - show buyer section by default and set required fields
            toggleRequiredFields('buyer');

            // Setup other input fields
            setupOtherInputs();

            // Initialize navigation
            showSection(0);
        });

        // Form submission handler
        document.getElementById('waitlistForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Final validation - check ALL required fields in the form
            const allRequiredFields = this.querySelectorAll('[required]');
            let isFormValid = true;
            let firstInvalidField = null;
            
            allRequiredFields.forEach(field => {
                // Skip hidden fields or fields in hidden sections
                if (field.offsetParent === null || field.disabled) {
                    return;
                }
                
                let fieldValid = true;
                
                if (field.type === 'radio') {
                    const radioGroup = this.querySelectorAll(`[name="${field.name}"]`);
                    fieldValid = Array.from(radioGroup).some(radio => radio.checked);
                } else if (field.type === 'checkbox') {
                    const checkboxGroup = this.querySelectorAll(`[name="${field.name}"]`);
                    fieldValid = Array.from(checkboxGroup).some(checkbox => checkbox.checked);
                } else if (field.tagName === 'SELECT') {
                    fieldValid = field.value.trim() !== '';
                } else {
                    fieldValid = field.value.trim() !== '';
                }
                
                if (!fieldValid) {
                    isFormValid = false;
                    if (!firstInvalidField) {
                        firstInvalidField = field;
                    }
                }
            });
            
            if (!isFormValid) {
                alert('Please fill in all required fields before submitting');
                if (firstInvalidField) {
                    try {
                        firstInvalidField.focus();
                    } catch (e) {
                        console.log('Could not focus field:', firstInvalidField.name);
                    }
                }
                return;
            }
            
            // Additional validation - make sure user has selected interests/products
            const userType = document.querySelector('input[name="user_type"]:checked').value;
            
            if (userType === 'buyer') {
                const interests = document.querySelectorAll('input[name="buyer_interests[]"]:checked');
                if (interests.length === 0) {
                    alert('Please select at least one food interest');
                    return;
                }
            } else if (userType === 'seller') {
                const products = document.querySelectorAll('input[name="products_sold[]"]:checked');
                if (products.length === 0) {
                    alert('Please select at least one product type');
                    return;
                }
            }
            
            // Show loading state
            const submitButton = document.querySelector('.submit-btn');
            const originalText = submitButton.textContent;
            submitButton.textContent = 'Submitting...';
            submitButton.disabled = true;
            
            
            /*setTimeout(() => {
                alert('Thank you! You\'ve been added to our waitlist. We\'ll be in touch soon!');
                
                // Reset form and close modal
                this.reset();
                document.getElementById('waitlistModal').style.display = 'none';
                document.body.style.overflow = 'auto';
                
                // Reset to first section
                currentSection = 0;
                showSection(0);
                
                // Reset button state
                submitButton.textContent = originalText;
                submitButton.disabled = false;
            }, 2000);
        });*/
            
fetch('send_email.php', {
    method: 'POST',
    body: new FormData(this)
})
.then(response => {
    if (!response.ok) {
        throw new Error('Network response was not ok');
    }
    return response.json();
})
.then(data => {
    if (data.status === 'success') {
        alert('Thank you! You\'ve been added to our waitlist. We\'ll be in touch soon!');
        
        // Reset form and close modal
        this.reset();
        document.getElementById('waitlistModal').style.display = 'none';
        document.body.style.overflow = 'auto';
        
        // Reset to first section
        currentSection = 0;
        showSection(0);
    } else {
        throw new Error(data.message || 'Submission failed');
    }
})
.catch(error => {
    alert('Error submitting form: ' + error.message);
    console.error('Error:', error);
})
.finally(() => {
    // Reset button state
    submitButton.textContent = originalText;
    submitButton.disabled = false;
});
});
    </script>

    <script>
        let currentSlideIndex = 0;
        const slides = document.querySelectorAll('.slide');
        const dots = document.querySelectorAll('.nav-dot');
        const totalSlides = slides.length;

        function showSlide(index) {
            // Remove active class from all slides and dots
            slides.forEach(slide => slide.classList.remove('active'));
            dots.forEach(dot => dot.classList.remove('active'));

            // Add active class to current slide and dot
            slides[index].classList.add('active');
            dots[index].classList.add('active');
        }

        function changeSlide(direction) {
            currentSlideIndex += direction;

            if (currentSlideIndex >= totalSlides) {
                currentSlideIndex = 0;
            } else if (currentSlideIndex < 0) {
                currentSlideIndex = totalSlides - 1;
            }

            showSlide(currentSlideIndex);
        }

        function currentSlide(index) {
            currentSlideIndex = index - 1;
            showSlide(currentSlideIndex);
        }

        // Auto slide functionality
        function autoSlide() {
            changeSlide(1);
        }

        // Start auto sliding
        let slideInterval = setInterval(autoSlide, 5000);

        // Pause auto slide on hover
        const heroContainer = document.querySelector('.hero-container');
        heroContainer.addEventListener('mouseenter', () => {
            clearInterval(slideInterval);
        });

        heroContainer.addEventListener('mouseleave', () => {
            slideInterval = setInterval(autoSlide, 5000);
        });

        // Keyboard navigation
        document.addEventListener('keydown', (e) => {
            if (e.key === 'ArrowLeft') {
                changeSlide(-1);
            } else if (e.key === 'ArrowRight') {
                changeSlide(1);
            }
        });

        // Touch/swipe support for mobile
        let touchStartX = 0;
        let touchEndX = 0;

        heroContainer.addEventListener('touchstart', (e) => {
            touchStartX = e.changedTouches[0].screenX;
        });

        heroContainer.addEventListener('touchend', (e) => {
            touchEndX = e.changedTouches[0].screenX;
            handleSwipe();
        });

        function handleSwipe() {
            const swipeThreshold = 50;
            const diff = touchStartX - touchEndX;

            if (Math.abs(diff) > swipeThreshold) {
                if (diff > 0) {
                    changeSlide(1); 
                } else {
                    changeSlide(-1); 
                }
            }
        }
    </script>


    <script>
    // Testimonial Slider
    let currentTestimonialIndex = 0;
    const testimonialSlides = document.querySelectorAll('.testimonial');
    const testimonialDots = document.querySelectorAll('.dot_nav');
    const totalTestimonialSlides = testimonialSlides.length;

    function showTestimonial(index) {
        // Remove present_now class from all testimonials and dots
        testimonialSlides.forEach(testimonial => {
            testimonial.classList.remove('present_now');
            testimonial.style.display = 'none';
        });
        testimonialDots.forEach(dot => dot.classList.remove('present_now'));

        // Add present_now class to current testimonial and dot
        testimonialSlides[index].classList.add('present_now');
        testimonialSlides[index].style.display = 'block';
        testimonialDots[index].classList.add('present_now');
    }

    function changeTestimonial(direction) {
        currentTestimonialIndex += direction;

        if (currentTestimonialIndex >= totalTestimonialSlides) {
            currentTestimonialIndex = 0;
        } else if (currentTestimonialIndex < 0) {
            currentTestimonialIndex = totalTestimonialSlides - 1;
        }

        showTestimonial(currentTestimonialIndex);
    }

    function currentTestimonial(index) {
        currentTestimonialIndex = index - 1;
        showTestimonial(currentTestimonialIndex);
    }

    // Initialize the slider
    showTestimonial(currentTestimonialIndex);

    // Auto-advance testimonials
    function autoAdvanceTestimonial() {
        changeTestimonial(1);
    }

    // Start auto-advance
    let testimonialInterval = setInterval(autoAdvanceTestimonial, 4000);

    // Pause auto-advance on hover
    const testimonialContainer = document.querySelector('.testimonial-container');
    testimonialContainer.addEventListener('mouseenter', () => {
        clearInterval(testimonialInterval);
    });

    testimonialContainer.addEventListener('mouseleave', () => {
        testimonialInterval = setInterval(autoAdvanceTestimonial, 4000);
    });

    // Keyboard navigation
    document.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowLeft') {
            changeTestimonial(-1);
        } else if (e.key === 'ArrowRight') {
            changeTestimonial(1);
        }
    });

    // Touch/swipe support for mobile
    let testimonialTouchStartX = 0;
    let testimonialTouchEndX = 0;

    testimonialContainer.addEventListener('touchstart', (e) => {
        testimonialTouchStartX = e.changedTouches[0].screenX;
    });

    testimonialContainer.addEventListener('touchend', (e) => {
        testimonialTouchEndX = e.changedTouches[0].screenX;
        handleTestimonialSwipe();
    });

    function handleTestimonialSwipe() {
        const swipeThreshold = 50;
        const diff = testimonialTouchStartX - testimonialTouchEndX;

        if (Math.abs(diff) > swipeThreshold) {
            if (diff > 0) {
                changeTestimonial(1); 
            } else {
                changeTestimonial(-1); 
            }
        }
    }
</script>
</body>
</html>